from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional
from typing_extensions import Literal

import yaml
import httpx

from ..types import (
    Task,
    DataResp,
    ListResp,
    TaskBrief,
    TaskModel,
    TaskVolume,
    TaskDataset,
    TaskStopResp,
    TaskCreateResp,
    TaskDeleteResp,
    TaskCreateParams,
    TaskEnhancements,
    TaskResubmitResp,
    TaskResubmitParams,
    TaskBatchDeleteResp,
    TaskBatchDeleteParams,
    TaskUserSelectedInstance,
)
from .._types import NOT_GIVEN, Body, Query, Headers, NotGiven
from .._utils import required_args, maybe_transform
from .._resource import SyncAPIResource
from .._response import to_raw_response_wrapper
from .._base_client import make_request_options

if TYPE_CHECKING:
    from .._client import SiFlow


__all__ = ["Tasks", "TasksWithRawResponse"]


class Tasks(SyncAPIResource):
    with_raw_response: TasksWithRawResponse

    def __init__(self, client: SiFlow) -> None:
        super().__init__(client)
        self.with_raw_response = TasksWithRawResponse(self)

    @required_args(
        ["yaml_file"],
        ["name_prefix", "image", "image_version", "image_url", "type", "cmd", "workers", "resource_pool", "instances"],
    )
    def create(
        self,
        *,
        yaml_file: Optional[str] | None = None,
        name_prefix: str | NotGiven = NOT_GIVEN,
        image: str | NotGiven = NOT_GIVEN,
        image_version: str | NotGiven = NOT_GIVEN,
        image_url: str | NotGiven = NOT_GIVEN,
        image_type: Optional[Literal["preset", "custom"]] | NotGiven = NOT_GIVEN,
        type: Literal["pytorchjob", "pod"] | NotGiven = NOT_GIVEN,
        cmd: str | NotGiven = NOT_GIVEN,
        workers: int | NotGiven = NOT_GIVEN,
        resource_pool: str | NotGiven = NOT_GIVEN,
        instances: List[TaskUserSelectedInstance] | NotGiven = NOT_GIVEN,
        volumes: Optional[List[TaskVolume]] = [],
        datasets: Optional[List[TaskDataset]] = [],
        models: Optional[List[TaskModel]] = [],
        enhancements: Optional[TaskEnhancements] | NotGiven = NOT_GIVEN,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> str:
        if yaml_file is not None:
            with open(yaml_file, "r") as f:
                params = yaml.safe_load(f)
            if "namePrefix" not in params:
                raise ValueError("missing 'namePrefix' in yaml file")
            if "image" not in params:
                raise ValueError("missing 'image' in yaml file")
            if "imageVersion" not in params:
                raise ValueError("missing 'imageVersion' in yaml file")
            if "imageUrl" not in params:
                raise ValueError("missing 'imageUrl' in yaml file")
            if "type" not in params:
                raise ValueError("missing 'type' in yaml file")
            if "cmd" not in params:
                raise ValueError("missing 'cmd' in yaml file")
            if "workers" not in params:
                raise ValueError("missing 'workers' in yaml file")
            if "resourcePool" not in params:
                raise ValueError("missing 'resourcePool' in yaml file")
            if "instances" not in params:
                raise ValueError("missing 'instances' in yaml file")
            if "volumes" not in params:
                params["volumes"] = []
            if "datasets" not in params:
                params["datasets"] = []
            if "models" not in params:
                params["models"] = []
        else:
            params = {
                "namePrefix": name_prefix,
                "image": image,
                "imageVersion": image_version,
                "imageUrl": image_url,
                "imageType": image_type,
                "type": type,
                "workers": workers,
                "volumes": volumes,
                "datasets": datasets,
                "models": models,
                "resourcePool": resource_pool,
                "instances": instances,
                "cmd": cmd,
                "enhancements": enhancements,
            }
        resp = self._post(
            "/task-service/v1/tasks",
            body=maybe_transform(params, TaskCreateParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TaskCreateResp,
        )
        return resp.data

    @required_args(["uuid"])
    def delete(
        self,
        *,
        uuid: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> str:
        resp = self._delete(
            f"/task-service/v1/tasks/{uuid}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TaskDeleteResp,
        )
        return resp.data

    @required_args(["uuids"])
    def batch_delete(
        self,
        *,
        uuids: List[str],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> List[str]:
        params = {
            "uuids": uuids,
        }
        resp = self._post(
            "/task-service/v1/tasks/deletion",
            body=maybe_transform(params, TaskBatchDeleteParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TaskBatchDeleteResp,
        )
        return resp.data

    @required_args(["uuid"])
    def stop(
        self,
        *,
        uuid: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> str:
        resp = self._get(
            f"/task-service/v1/tasks/stop/{uuid}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TaskStopResp,
        )
        return resp.data

    @required_args(["uuid"])
    def get(
        self,
        *,
        uuid: str,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> Task:
        resp = self._get(
            f"/task-service/v1/tasks/{uuid}",
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=DataResp[Task],
        )
        return resp.data

    def list(
        self,
        *,
        count: int = 15,
        status: str | None = None,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> List[TaskBrief]:
        query: Query = {
            "page": "1",
            "pageSize": str(count),
        }
        if status is not None:
            query["status"] = status
        resp = self._get(
            "/task-service/v1/tasks",
            options=make_request_options(
                extra_headers=extra_headers,
                extra_query=extra_query,
                extra_body=extra_body,
                timeout=timeout,
                query=query,
            ),
            cast_to=ListResp[TaskBrief],
        )
        return resp.rows

    @required_args(["uuids"])
    def resubmit(
        self,
        *,
        uuids: List[str],
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = NOT_GIVEN,
    ) -> List[str]:
        params = {
            "uuids": uuids,
        }
        resp = self._post(
            "/task-service/v1/tasks/resubmission",
            body=maybe_transform(params, TaskResubmitParams),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=TaskResubmitResp,
        )
        return resp.data


class TasksWithRawResponse:
    def __init__(self, tasks: Tasks) -> None:
        self.create = to_raw_response_wrapper(tasks.create)
        self.delete = to_raw_response_wrapper(tasks.delete)
        self.batch_delete = to_raw_response_wrapper(tasks.batch_delete)
        self.stop = to_raw_response_wrapper(tasks.stop)
        self.get = to_raw_response_wrapper(tasks.get)
        self.list = to_raw_response_wrapper(tasks.list)
        self.resubmit = to_raw_response_wrapper(tasks.resubmit)
