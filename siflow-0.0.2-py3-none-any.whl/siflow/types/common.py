from __future__ import annotations

from pydantic import Field
from typing import Generic, Optional, List

from .._types import ModelT
from .._models import GenericModel


class DataResp(GenericModel, Generic[ModelT]):
    status: bool
    """response status"""

    message: str = Field(alias="msg")
    """message of response status"""

    data: ModelT
    """actual data"""


class ListResp(GenericModel, Generic[ModelT]):
    status: bool
    """response status"""

    message: str = Field(alias="msg")
    """message of response status"""
    
    total: Optional[int]
    """total items"""
    
    rows: List[ModelT]
    """list of models"""


class DataListResp(GenericModel, Generic[ModelT]):
    status: bool
    """response status"""

    message: str = Field(alias="msg")
    """message of response status"""

    data: List[ModelT]
    """actual data"""
