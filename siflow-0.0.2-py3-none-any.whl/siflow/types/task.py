from __future__ import annotations

from typing import List, Union, Optional
from typing_extensions import Literal, Required, Annotated, TypedDict

from pydantic import Field

from .._utils import PropertyInfo
from .._models import BaseModel


# entities
class TaskVolume(TypedDict, total=False):
    volume_id: Annotated[int, PropertyInfo(alias="volumeId")]
    """id of volume in db"""

    mount_dir: Annotated[str, PropertyInfo(alias="mountDir")]
    """the path of the volume mounted in task pod"""


class TaskDataset(BaseModel):
    name: str
    """dataset name"""

    version: Optional[str]
    """dataset version"""

    type: Optional[Literal["preset", "custom"]]
    """dataset type"""

    pvc_name: Optional[str] = Field(alias="pvc")
    """pvc name of dataset"""

    sub_path: Optional[str] = Field(alias="subPath")
    """relative path of dataset in volume"""

    mount_path: str = Field(alias="mountPath")
    """dataset mount path in task pod"""


class TaskModel(BaseModel):
    name: str
    """model name"""

    version: Optional[str]
    """model version"""

    type: Optional[Literal["preset", "custom"]]
    """model type"""

    pvc_name: Optional[str] = Field(alias="pvc")
    """pvc name of model"""

    sub_path: Optional[str] = Field(alias="subPath")
    """relative path of model in volume"""

    mount_path: str = Field(alias="mountPath")
    """model mount path in task pod"""


class TaskUserSelectedInstance(TypedDict, total=False):
    name: str
    """instance name"""

    count_per_pod: Annotated[int, PropertyInfo(alias="countPerPod")]
    """instance number should used by one task pod"""


class TaskSystemSelectedInstance(BaseModel):
    name: str
    """instance name"""

    count_total: int = Field(alias="countTotal")
    """total instance number used by task"""


class TaskEnhancementsFaultTolerance(TypedDict, total=False):
    enabled: Optional[bool]
    """enable fault tolerance"""

    max_retry_count: Annotated[Optional[int], PropertyInfo(alias="maxRetryCount")]
    """max retry count when task error"""


class TaskEnhancements(TypedDict, total=False):
    fault_tolerance: Annotated[Optional[TaskEnhancementsFaultTolerance], PropertyInfo(alias="faultTolerance")]
    """fault tolerance config"""


class TaskBrief(BaseModel):
    uuid: str
    """uuid of task"""

    cluster: str
    """cluster"""

    name: str
    """task name"""

    resource_pool: str = Field(alias="resourcePool")
    """instance resource pool"""

    instances: List[TaskUserSelectedInstance]
    """instances params when create task"""

    selected_instances: List[TaskSystemSelectedInstance] = Field(alias="selectedInstances")
    """selected instance"""

    volumes: List[TaskVolume]
    """volumes mounted by task"""

    image: str
    """image name"""

    image_version: str = Field(alias="imageVersion")
    """image version"""

    image_url: str = Field(alias="imageUrl")
    """image url"""

    image_type: str = Field(alias="imageType")
    """image type"""

    status: Union[
        str,
        Literal[
            "Pending", "Running", "Failed", "Succeeded", "Error", "PartialPending", "Unknown", "Stopping", "Stopped"
        ],
    ]
    """task status"""

    status_msg: str = Field(alias="statusMsg")
    """message of task status"""

    create_time: Optional[str] = Field(alias="createTime")
    """create time"""

    update_time: Optional[str] = Field(alias="updateTime")
    """update time"""

    start_time: Optional[str] = Field(alias="startTime")
    """start time"""

    end_time: Optional[str] = Field(alias="endTime")
    """end time"""

    duration: Optional[str] = Field(alias="duration")
    """duration"""


class Task(TaskBrief):
    name_prefix: str = Field(alias="namePrefix")
    """name prefix of task"""

    type: Literal["pytorchjob", "pod"]
    """task type"""

    workers: int
    """worker count of task"""

    cmd: str
    """command of task"""

    datasets: Optional[List[TaskDataset]] = None
    """datasets used by task"""

    models: Optional[List[TaskModel]] = None
    """models used by task"""

    enhancements: Optional[TaskEnhancements] = None
    """enhancements configs"""


# requests
class TaskCreateParams(TypedDict, total=False):
    name_prefix: Required[Annotated[str, PropertyInfo(alias="namePrefix")]]
    """name prefix for task"""

    image: Required[str]
    """image name of task pod"""

    image_version: Required[Annotated[str, PropertyInfo(alias="imageVersion")]]
    """image version"""

    image_url: Required[Annotated[str, PropertyInfo(alias="imageUrl")]]
    """harbor url of image"""

    image_type: Annotated[Optional[Literal["preset", "custom"]], PropertyInfo(alias="imageType")]
    """image type"""

    type: Required[Annotated[Literal["pytorchjob", "pod"], PropertyInfo(alias="type")]]
    """task type"""

    workers: Required[int]
    """worker number of task"""

    volumes: Required[List[TaskVolume]]
    """volumes should mount by task"""

    datasets: List[TaskDataset]
    """datasets should used by task"""

    models: List[TaskModel]
    """models should used by task"""

    resource_pool: Required[Annotated[str, PropertyInfo(alias="resourcePool")]]
    """instance resource pool name"""

    instances: Required[List[TaskUserSelectedInstance]]
    """instance types and numbers used by task"""

    cmd: Required[str]
    """entrance command of task"""

    enhancements: Optional[TaskEnhancements]
    """enhancement configs"""


class TaskCreateResp(BaseModel):
    status: bool
    """response status"""

    msg: str
    """message of response status"""

    data: str
    """task uuid"""


class TaskDeleteResp(BaseModel):
    status: bool
    """response status"""

    msg: str
    """message of response status"""

    data: str
    """task uuid"""


class TaskBatchDeleteParams(TypedDict, total=False):
    uuids: Required[List[str]]
    """task uuids to delete"""


class TaskBatchDeleteResp(BaseModel):
    status: bool
    """response status"""

    msg: str
    """message of response status"""

    data: List[str]
    """task uuids"""


class TaskStopResp(BaseModel):
    status: bool
    """response status"""

    msg: str
    """message of response status"""

    data: str
    """task uuid"""


class TaskResubmitParams(TypedDict, total=False):
    uuids: Required[List[str]]
    """task uuids to resubmit"""


class TaskResubmitResp(BaseModel):
    status: bool
    """response status"""

    msg: str
    """message of response status"""

    data: List[str]
    """task uuids"""
